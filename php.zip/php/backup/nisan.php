<html>
<head>
<title>PickCar</title>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="carstyle.css">
<link rel="icon" 
      type="image/png" 
      href="https://cdn.dribbble.com/users/462691/screenshots/2921080/dribbble_1x.png">
<style>
p{

}</style>
 </head>
 <body>
<section>
        
            <div class="container">
            
                <div class="row">
                
                    <div class="col-md-10 col-md-offset-1">
                    
                        <!-- About us Title & Description -->
                        <div class="section-title">
                        
                            <h2>Nisan Maruno</h2>
                            <p>.The 2017 Nissan Murano offers the comfort, performance and refinement typical of luxury SUVs, but without the hefty price tag.</p>
                        
                        
                        </div>
                    
                    
                    
                    </div>
                
                </div>
            
            
            </div>
        
            <div class="choose-us-wraper">
            
                <div class="container">
                
                    <div class="row">
                    
                        <div class="col-md-6">
                        
                            <!-- About iphone -->
                            <div class="about-iphone">
                            
                                <img src="nisan-maruno.jpg" width="450px" height="450px" alt="iphone">
                            
                            </div>
                        
                        </div>
                        
                        <div class="col-md-6">
                            <div class="choose-us-title">
                            
                            
                                <h2>Description</h2>
                                <p>The 2017 Nissan Murano ranks 5 out of 19 Midsize SUVs. The 2017 Nissan Murano offers the comfort, performance and refinement typical of luxury SUVs, but without the hefty price tag. Its interior outclasses those of most competing vehicles, and it delivers a cushioned, smooth ride over most surfaces. However, you may wish it were a bit more engaging to drive.The 2017 Nissan Murano offers the comfort, performance and refinement typical of luxury SUVs, but without the hefty price tag. Its interior outclasses those of most competing vehicles, and it delivers a cushioned, smooth ride over most surfaces. However, you may wish it were a bit more engaging to drive.The Nissan Murano is a good SUV and should be near the top of your shopping list. It's a well-rounded vehicle that has the latest technology, an upscale interior, and excellent fuel economy. It's also a safe and reliable crossover that boasts excellent safety scores and is recognized as a 2017 Top Safety Pick by the Insurance Institute for Highway Safety. It also has an impressive track record of reliability and a long list of safety features. In addition to all that, we named the Nissan Murano the 2017 Best 2-Row SUV for the Money because it has the best combination of quality and value in the class. </p>
                                <button type="button" class="btn btn-default submit-btn form_submit">SEND</button>
                            
                            </div>
                             
                            
                            </div>
                            
                            
                            
                        
                        </div>
                    
                    </div>
                
                </div>
        
        
        </section>



 </body>