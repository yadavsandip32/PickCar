<!DOCTYPE html>
<head> 
<title>Book Now</title>
<meta name="viewport" content-type=" width=device-width initial-scale=1">
<link rel="stylesheet" type="text/css" href="../css/BookStyle.css">
<link rel="stylesheet" type="text/css" href="../css/carstyle.css">
<link rel="icon" 
      type="image/png" 
      href="../images/dribbble_1x.png">
	  
<body>
<center>
<div class="container">
 <div class="Header">
	   <br>
	   <br>
	   <br>
	 <h1>More than 10,000+ of cars to choose from</h1>
	 <p align="left">
	 &nbsp;&nbsp;&nbsp;
	 <a href="http://c403.pe.hu/"><img width="10%" src="http://4.bp.blogspot.com/-vAXScY8Zooo/VJDCMWzDBBI/AAAAAAAAOP8/os6ewYlrnR8/s1600/How+to+Make+Flat+Icon+Media+Social+using+Inkscape.png"></a></p>
 <br>
 </div>
 <br>
 <div class="Sort">   
       <table>
	   <tr>
	   <td>
        <a href="../index.php">
        <img  width="50px" src="../images/dribbble_1x.png"></a>
        </td>
		<td><div class="heading">PickCar.com</div></td><td>
		<input type="text" placeholder="Search car">&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="Submit" name="Go" value="Go">

		<td>
		   <a href="Signup.php" style="text-decoration:none ; color:white">Create an Account</a></td>
		   <td><a href="Login.php" style="text-decoration:none; color:white"> Log In</a></td>
		   <td><a href="index.php" style="text-decoration:none; color:white">Help</a></td>
</table>

 </div> 
 
<div class="describe">
<h2>Hyundai Creta</h2><br>
<table cellspacing="2px" cellpadding="5px">
<tr>
<td rowspan="9"><img src="../images/budget2.jpg"></td>
<td>: Features :</></td>
<tr>
<td>Ex-showroom Price New Delhi	</td><td>Rs 7,91,700Finance Quotes</td><tr>
<td>Mileage (ARAI) kmpl	<td>22.77 kmpl</td><tr>
<td>Mileage (City) kmpl<td>	-</td><tr>
<td>Fuel Type	<td>Diesel</td><tr>
<td>Engine Displacement	<td>1498 cc</td><tr>
<td>BHP	<td>98.59bhp@3750rpm</td><tr>
<td>Torque	<td>205Nm@1750-3250rpm</td>
<tr>
<td colspan="3"><input type="button" value="Book Now"></td>
</table>
</div>



 <div class="border">
</div> 


<div class="footer">
<h4>Copyright © 2017 Aditya Thaokar,RAIT,New Mumbai.</h4></div>
</center>
</body>
</html>